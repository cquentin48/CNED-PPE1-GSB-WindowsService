﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClotureFrais
{
    class Program
    {
        static void Main(string[] args)
        {
            string mois = GestionDate.getMoisPrecedent();
            Console.WriteLine(mois);
            Console.ReadKey();
        }
    }
}
