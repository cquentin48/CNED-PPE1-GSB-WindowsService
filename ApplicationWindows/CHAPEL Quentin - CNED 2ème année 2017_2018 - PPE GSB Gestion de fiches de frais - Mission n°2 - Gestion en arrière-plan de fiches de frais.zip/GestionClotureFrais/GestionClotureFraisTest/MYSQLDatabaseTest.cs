﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using GestionClotureFrais;

namespace GestionClotureFraisTest
{
    [TestClass]
    public class MysqlDatabaseTest
    {
        private MysqlDatabase conTest;

        [TestMethod]
        public void ClotureFiche()
        {
            conTest.clotureFiches();
        }

        public void ValidationFiche() {
            conTest.validationFiches();
        }
    }
}
